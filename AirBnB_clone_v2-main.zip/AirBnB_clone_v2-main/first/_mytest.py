#!/usr/bin/python3

args = 'State name="California"'

myclass = args[:args.find(' ')]
print(myclass)